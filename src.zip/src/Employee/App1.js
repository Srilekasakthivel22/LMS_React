import React from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import EmpDashBoard from './EmpDashBoard';
import EmpLogin from './EmpLogin';



export default function App1() {
    return (
        <div>
            <BrowserRouter>
            <Link to="">EmpLogin</Link><br></br>
            <Link to="/EmpDashBoard">EmpDashBoard</Link><br></br>
            <Routes>
            <Route path="" element={<EmpLogin/>}></Route>
                <Route path="/EmpDashBoard" element={<EmpDashBoard/>}></Route>
            </Routes>
            </BrowserRouter>
            
        </div>
    )
}
