import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import axios from 'axios';
import './EmpLogin.css';









export default class EmpLogin extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            EmployeeEmailId:"",
            EmployeePassword:"",
            Emailerror:"",
            Passworderror:""
        }
        this.submit=this.submit.bind(this);
       
       
        
    }
    validate()
    {
       if(this.state.EmployeeEmailId=="" && this.state.EmployeePassword=="")
       {
           alert("Pls enter mail id and password");
           
       } 
       else if(this.state.EmployeeEmailId=="")
       {
           this.setState({Emailerror:"Pls enter email id"});
       }
       else if(this.state.EmployeePassword=="")
       {
           this.setState({Passworderror:"Pls enter password"});
       }
       else if(!this.state.EmployeeEmailId.includes("@"))
       {
          this.setState({Emailerror:"Email must have @"});
       }
    }
    submit()
    {
        this.validate();
        let emailid=this.state.EmployeeEmailId;
        let password=this.state.EmployeePassword;
        let url='http://localhost:20969/api/Employee/'+emailid+'/'+password
        axios.get(url).then(response=>response).then(result=>{
            let res=result.data
            if(res!=null)
            {
                alert("Welcome to Home Page");
                window.location ="/EmpDashBoard";
            }
           
        }).catch(err=>{
            alert("Enter correct data");
            console.warn("err");
         } );
    }
    handleChange(e)
    {
        this.setState(e);
    }
    render() {
        return (
            
                <form >
                   
                    
  <div class="form-group">
      
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" onChange={(e)=>this.handleChange({EmployeeEmailId:e.target.value})} aria-describedby="emailHelp" placeholder="Enter email"/>
    <p >{this.state.Emailerror}</p>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" onChange={(e)=>this.handleChange({EmployeePassword:e.target.value})} id="exampleInputPassword1" placeholder="Password"/>
    <p> {this.state.Passworderror}</p>
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input"  id="exampleCheck1"/>
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary" onClick={this.submit}>Submit</button>
 
</form>
            
        )
    }
}