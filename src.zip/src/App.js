import logo from './logo.svg';
import './App.css';
import Login from './Login';
import EmpLogin from './Employee/EmpLogin'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import EmpDashBoard from './Employee/EmpDashBoard';




function App() {
  return (
    <div className="App">
      <BrowserRouter>
           
            
            <Routes>
            <Route path="" element={<EmpLogin/>}></Route>
                <Route path="/EmpDashBoard" element={<EmpDashBoard/>}></Route>
            </Routes>
            </BrowserRouter>
      </div>
  );
}

export default App;
