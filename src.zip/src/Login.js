import axios from 'axios';
import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import './Login.css';



export default class Login extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            EmployeeEmailId:"",
            EmployeePassword:""
        }
        this.submit=this.submit.bind(this);
       
        
    }
    submit()
    {
        let emailid=this.state.EmployeeEmailId;
        let password=this.state.EmployeePassword;
        let url='http://localhost:20969/api/Employee/'+emailid+'/'+password
        axios.get(url).then(response=>response).then(result=>{
            let res=result.data
            if(res!=null)
            {
                alert("Welcome to Home Page");
                // window.location="/EmployeeHomePage";
            }
        }).catch(err=>{
            alert("Enter correct data");
            console.warn("err");
         } );
    }
    handleChange(e)
    {
        this.setState(e);
    }
    render() {
        return (
            <form class="body">
            <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control" onChange={(e)=>this.handleChange({EmployeeEmailId:e.target.value})}>EmailId</input>
              
            </div>
            <div class="mb-3">
            <label for="exampleInputPassword1">Password</label>
              <input type="password" class="form-control" onChange={(e)=>this.handleChange({EmployeePassword:e.target.value})}>Password</input>
            </div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
              <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary" onClick={this.submit}>Submit</button>
          </form>
        )
    }
}
